<body>
    <div id="root" style="overflow:hidden;">
       <?php echo $header; ?>
        <main class="mainz" style=" background-color: #ffffff; ">
            <section class="container gt1 wrapcontentHome">
                <div class="sty">
                    <div class="wrap-list">
                        <div class="lis-category">
                            <div class="header-cate re">
                                <h2 class="title-h3-1">Không tìm thấy trang. </h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row category-mn">
                   <?php echo $html_xu_huong; ?>
                </div>
            </section>
        </main>
        <?php echo $footer; ?>
    </div>
    <script src="<?php echo $home_url;?>/wp-content/themes/shopseo/templates/src/js.js"></script>
    <script type="text/javascript"> document.addEventListener('copy', function (e) { e.preventDefault(); }); document.addEventListener('contextmenu', function (e) { e.preventDefault(); }); </script>
</body>