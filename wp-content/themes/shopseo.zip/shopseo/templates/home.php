<?php
/*
Template Name: Home
*/
?>
<?php
    require_once(get_stylesheet_directory().'/templates/home/home.php');
?>