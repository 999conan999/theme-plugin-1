<?php
    $type='page';
    // $common= get_common();//
    $home_url=get_home_url();
    $home_name=str_replace('https://', '', $home_url);
    $home_name=str_replace('http://', '', $home_name);
    $data=get_home_infor($id);
    // var_dump($data->category_data_list);
?>