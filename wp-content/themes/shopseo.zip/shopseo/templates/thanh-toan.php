<?php
/*
Template Name: checkout
*/
?>
<?php
    require_once(get_stylesheet_directory().'/templates/checkout/checkout.php');
?>