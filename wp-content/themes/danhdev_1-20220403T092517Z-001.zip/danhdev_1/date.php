<!DOCTYPE html>
<html>
<head>
<meta name="robots" content="noindex" />
</head>
<body>
<h1>>>> Go Back <a href="<?php echo get_home_url() ?>" style=" color: #3f51b5; "><?php echo get_home_url() ?></a></h1>
</body>
</html>