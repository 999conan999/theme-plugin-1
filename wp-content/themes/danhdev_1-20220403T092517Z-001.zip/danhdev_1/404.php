<?php
require_once(get_stylesheet_directory().'/templates/404/404.php');
//









"<?php echo get_stylesheet_directory_uri().'/templates/assets/css/icon/background-image.svg';?>"



"<?php echo get_stylesheet_directory_uri().'/templates/assets/css/icon/fontawesome-webfont.svg?v=4.0.3#fontawesomeregular';?>"



?>