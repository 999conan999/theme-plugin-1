<link href="<?php echo get_stylesheet_directory_uri().'/templates/assets/brand/tip.png'; ?>" rel="shortcut icon" type="image/x-icon">
    <link href="<?php echo get_stylesheet_directory_uri().'/templates/assets/brand/tip.png'; ?>" rel="apple-touch-icon">
    <link href="<?php echo get_stylesheet_directory_uri().'/templates/assets/brand/tip.png'; ?>" rel="apple-touch-icon-precomposed">