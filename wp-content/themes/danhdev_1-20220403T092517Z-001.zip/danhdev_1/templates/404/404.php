<?php
    // $url_req = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    // preg_match_all('/\/\?s\=(.*)/',$url_req,$k1);
    // $words = preg_replace('/[0-9]+/', '', urldecode($k1[1][0]));
    // $search_rsult=str_replace('-',"+",fixForUri($words));
    // $url_redir=get_home_url().'/?s='.$search_rsult;
    // wp_redirect( $url_redir, 301 );
    // exit();
?>