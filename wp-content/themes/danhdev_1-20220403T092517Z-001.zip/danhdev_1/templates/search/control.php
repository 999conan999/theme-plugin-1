<?php
    $key=preg_replace('/[0-9]+/', '',strip_tags($_GET['s']));
    $args=array("post_type" => "post",'post_status' => 'publish', "s" => $key,'posts_per_page' => 21,'offset'=>0,'orderby'=> 'title','order'=> 'ASC' );
    $query=array();
    if($key !=""){
         $query = get_posts( $args );
    }
    // //
    $home=get_home_url();
    preg_match_all('/\/\/(.*)/',$home,$name_url);
    $name_website=$name_url[1][0];
    $url=$home.'/?s='.fixForUri($key);
    $is_have=true;
    $show_card="";
    $canonical_count=0;
    if(count($query)>0){
        foreach($query as $post){
            $canonical_count++;
            $title_post=$post->post_title;
            $short_des=get_post_meta($post->ID, 'mo_ta_ngan', true );
            $img_src_1=wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' );
            $link_post=get_permalink($post->ID);
            $show_card.='<a href="'.$link_post.'" title="'.$title_post.'" style=" color: #060606; cursor: pointer; "> <div class="card card-5  gradient gradient--1"> <h2 style="color: #2b2b2b; margin: 6px;overflow: hidden; line-height: 26px; word-wrap: break-word; text-overflow: ellipsis; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2; ">';
            $show_card.=$title_post.'</h2><hr> <div style=" min-height: 158.8px; "> <img itemprop="image" src="';
            $show_card.=$img_src_1.'" alt="'.$title_post.' 1" title="'.$title_post.' 1" style=" width: 49%; display: block; ">';
            $show_card.='</div> <p class="text-hinden">';
            $show_card.=$short_des.'</p></div></a>';
            $is_have=false;
        }
    }
    if($canonical_count>=4){
    	$contents_robot="INDEX,FOLLOW";
        $canonical=$url;
    }else{
   	$contents_robot="noindex";
        $canonical=$home;
    }
    if($is_have) $show_card='<p>Không tìm thấy <strong>'.$key.'</strong>, các bạn xem thêm tại đây : <a href="'.get_home_url().'" title="'.$name_website.'">'.$name_website.'</a> </p>';
?>