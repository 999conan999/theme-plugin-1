<?php //require_once(get_stylesheet_directory().'/templates/search/control.php'); ?>
<?php
echo "search";
?>
