<?php
//Header set Access-Control-Allow-Origin "*"
    function fs_get_data_theme($keyz){
        global $wpdb;
        $table_prefix = $wpdb->prefix . 'data_theme';
        $sql = $wpdb->prepare( "SELECT keyz,valuez FROM $table_prefix WHERE keyz =%s ",$keyz);
        $results = $wpdb->get_results( $sql , OBJECT );
        if(count($results)>0){
            return json_decode($results[0]->valuez);
        }else{
            return 'null';
        }
    }
    function fs_get_post_by_category_id($id_cate,$quantity_post,$offset=0){
        global $wpdb;
        $list_childrent=(get_term_children($id_cate,'category'));
        $args = array('cat' => $id_cate, 'orderby' => 'post_date', 'order' =>'DESC', 'posts_per_page' => $quantity_post,'post_status' => 'publish','offset' => $offset,'category__not_in' =>$list_childrent);
        $results =query_posts($args);
        //
        $cat = get_category($id_cate);
        $obj=$object = new stdClass();
        $obj->category_id=$cat->term_id;
        $obj->count=$cat->count;
        $obj->category_name=$cat->name;
        $obj->category_thumnail_url=get_term_meta($id_cate,'thumnail_url', true);
        $obj->descriptions=get_term_meta($id_cate,'descriptions', true);
        $obj->category_url=get_category_link($cat->term_id);
        $list_posts=array(); 
        foreach($results as $x){
            $result = new stdClass();
            $result->post_modified=$x->post_modified;
            $result->id=$x->ID;
            $result->post_title=$x->post_title;
            $result->descriptions=get_post_meta($x->ID,'descriptions', true);
            $result->post_url=get_permalink($x->ID);
            $result->thumnail_url=get_post_meta($x->ID,'thumnail_url', true);
            array_push($list_posts,$result);
        };
        $obj->list_posts=$list_posts;
        return $obj;
    }
    function fs_get_info_post_card($id){
        global $wpdb;
        $table_prefix=$wpdb->prefix .'posts';
        $sql = $wpdb->prepare( "SELECT ID,post_modified,post_title FROM $table_prefix WHERE ID= %d ",$id);
        $results = $wpdb->get_results( $sql , OBJECT );
        if(count($results)>0){
            $result = new stdClass();
            $result->post_modified=$results[0]->post_modified;
            $result->id=$results[0]->ID;
            $result->post_title=$results[0]->post_title;
            $result->post_url=get_permalink($results[0]->ID);
            $result->thumnail_url=get_post_meta($results[0]->ID,'thumnail_url', true);
            return $result;
        }else{
            $result = new stdClass();
            $result->post_modified='';
            $result->post_title='';
            $result->post_url='';
            $result->thumnail_url='';
            return $result;
        }
    }
    function fs_check_category_created($id){
        global $wpdb;
        $table_prefix=$wpdb->prefix .'term_taxonomy';
        $sql = $wpdb->prepare( "SELECT COUNT(term_taxonomy_id) FROM $table_prefix WHERE term_id= %d AND taxonomy='category' ",$id);
        $results = $wpdb->get_results( $sql , ARRAY_A );
        if((int)$results[0]["COUNT(term_taxonomy_id)"]>0) return true;
        return false;
    }
    function fs_get_child_category_by_category_parent_id($id){//home
        $cat = get_category( $id);
        $object = new stdClass();
        $object->category_id=$cat->term_id;
        $object->category_name=$cat->name;
        $object->category_url=get_category_link($cat->term_id);
        $list_childrent=(get_term_children($id,'category'));
        $category_childrent_list=array();
        foreach($list_childrent as $c){
            $cat = get_category( $c );
            $object_childrent = new stdClass();
            $object_childrent->category_childrent_id=$c;
            $object_childrent->category_childrent_name=$cat->name;
            $object_childrent->category_childrent_url=get_category_link($c);
            $object_childrent->category_childrent_thumnail=get_term_meta($c,'thumnail_url', true);
            array_push($category_childrent_list,$object_childrent);
        }
        $object->category_child_list=$category_childrent_list;
        return $object;
    }
    function fs_get_info_category_by_id_show_cate($id){//category show category list
        $cat = get_category( $id);
        $object = new stdClass();
        $object->category_id=$cat->term_id;
        $object->category_name=$cat->name;
        $object->category_url=get_category_link($cat->term_id);
        $object->category_thumnail_url=get_term_meta($id,'thumnail_url', true);
        $metaA=json_decode(get_term_meta($id,'metaA', true));
        $object->descriptions=$metaA->descriptions;
        $list_childrent=(get_term_children($id,'category'));
        $category_childrent_list=array();
        foreach($list_childrent as $c){
            $cat = get_category( $c );
            $object_childrent = new stdClass();
            $object_childrent->category_childrent_id=$c;
            $object_childrent->category_childrent_name=$cat->name;
            $object_childrent->category_childrent_url=get_category_link($c);
            $object_childrent->category_childrent_thumnail=get_term_meta($c,'thumnail_url', true);
            $metaA=json_decode(get_term_meta($c,'metaA', true));
            $object_childrent->descriptions=$metaA->descriptions;
            array_push($category_childrent_list,$object_childrent);
        }
        $object->category_child_list=$category_childrent_list;
        return $object;
    }














?>