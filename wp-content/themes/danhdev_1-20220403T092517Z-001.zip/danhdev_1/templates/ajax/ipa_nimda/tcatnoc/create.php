<?php 
    $parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
    require_once( $parse_uri[0] . 'wp-load.php' );

    
function create_form($namez,$phone,$address,$city,$note,$orderz,$gender,$cost,$email,$typez,$value_1,$value_2,$value_3,$value_4,$value_5,$value_6,$value_7,$value_8){
    $data = array(
        'namez'=> $namez,
        'phone' => $phone,
        'address' => $address,
        'city' => $city,
        'note' => $note,
        'orderz' => $orderz,
        'gender' => $gender,
        'cost' => $cost,
        'email' => $email,
        'typez' => $typez,
        'datez' => current_time( 'mysql'),
        'value_1' => $value_1,
        'value_2' => $value_2,
        'value_3' => $value_3,
        'value_4' => $value_4,
        'value_5' => $value_5,
        'value_6' => $value_6,
        'value_7' => $value_7,
        'value_8' => $value_8,
    );
    global $wpdb;
    $table = $wpdb->prefix . 'contacts_form';
    $wpdb->insert(
        $table,
        $data
    );
}
// create_form('Meo Thị','0963225874','34 nhất chi mai, p13','HCM','note','order','male','cost','thimeo.bk@gmai.com','type','value_1','value_2','value_3','value_4','value_5','value_6','value_7','value_8');


?>