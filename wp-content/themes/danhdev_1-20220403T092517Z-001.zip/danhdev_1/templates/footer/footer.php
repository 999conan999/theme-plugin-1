<footer id="lien-he">
    <div class="footer-3 footer-4">
        <div class="footer-container">
            <div class="panel-2">
                <div class="panel-body-2 footer-2-panel-body ">
                    <div class="widget_text item-footer">
                        <div class="textwidget custom-html-widget">
                            <div class="social-nptruyen">
                                <div class=" top-social container-nptruyen">
                                    <div class="top-social-item"><a
                                            href="<?php echo(isset($data_setup->footer_setup->url_fb)?$data_setup->footer_setup->url_fb:'');?>" target="_blank"
                                            rel="noopener nofollow external noreferrer" data-wpel-link="external"><img width="50" height="50" class='lazyload' data-src="<?php echo get_stylesheet_directory_uri().'/templates/assets/css/icon/facebook.png';?>"><noscript><img width="50" height="50" src="<?php echo get_stylesheet_directory_uri().'/templates/assets/css/icon/facebook.png';?>"></noscript><span><?php echo(isset($data_setup->footer_setup->title_fb)?$data_setup->footer_setup->title_fb:'');?></span></a>
                                    </div>
                                    <div class="top-social-item"><a
                                            href="<?php echo(isset($data_setup->footer_setup->url_youtube)?$data_setup->footer_setup->url_youtube:'');?>"
                                            target="_blank" rel="noopener nofollow external noreferrer"
                                            data-wpel-link="external"><img width="50" height="50" class='lazyload' data-src="<?php echo get_stylesheet_directory_uri().'/templates/assets/css/icon/youtube.png';?>"><noscript><img
                                                    width="50" height="50"
                                                    src="<?php echo get_stylesheet_directory_uri().'/templates/assets/css/icon/youtube.png';?>"></noscript><span>
                                                <span style="vertical-align: inherit;">
                                                    <span style="vertical-align: inherit;"><?php echo(isset($data_setup->footer_setup->title_youtube)?$data_setup->footer_setup->title_youtube:'');?></span>
                                                </span>
                                            </span></a>
                                        <p></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text-small footer-2-subtext">
                            <div class="widget_text cont-map">
                                <div class="textwidget custom-html-widget">
                                    © <?php echo date('Y'); ?> <?php echo(isset($data_setup->footer_setup->design_by)?$data_setup->footer_setup->design_by:'');?> <br> 
                                    email:<b> <?php echo(isset($data_setup->footer_setup->email)?$data_setup->footer_setup->email:'');?></b>
                                </div>
                            </div>                
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</footer>  
    <script data-minify="1" type="text/javascript" src="<?php echo get_stylesheet_directory_uri().'/templates/assets/js/jquery.js';?>" id="script--js" defer=""></script>
    <script data-minify="1" type="text/javascript" src="<?php echo get_stylesheet_directory_uri().'/templates/assets/js/learn.js';?>" id="script-0-js" defer=""></script>
    <script data-minify="1" type="text/javascript" src="<?php echo get_stylesheet_directory_uri().'/templates/assets/js/main.js';?>" id="script-main-js" defer=""></script>
    <script data-minify="1" type="text/javascript" src="<?php echo get_stylesheet_directory_uri().'/templates/assets/js/lazyload.js';?>" id="script-main-js" defer=""></script>