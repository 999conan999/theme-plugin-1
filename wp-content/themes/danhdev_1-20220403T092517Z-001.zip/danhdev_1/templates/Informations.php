<?php
/*
Template Name: Informations
*/
?>
<?php
    echo "informations";
?>