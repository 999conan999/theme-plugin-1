<?php
    $home_url=get_home_url();
    preg_match_all('/\/\/(.*)/',$home_url,$name_url);
    $name_website=$name_url[1][0];
    $link_post=get_page_link();
    $title=get_the_title();
    $img=wp_get_attachment_url( get_post_thumbnail_id($id), 'thumbnail' );
    $content=get_the_content();
    $cate=get_the_category($id)[0];
    $link_cate=get_category_link($cate->term_id);
    $name_cate=$cate->name;
    $slug_cate=$cate->slug;
    $short_des=get_post_meta($id, 'mo_ta_ngan', true );
    $tu_khoa_lien_quan=get_post_meta($id, 'tu_khoa_lien_quan', true );
    // 
    $day_dept=floor(((int)current_time('timestamp')-(int)$time_post)/86400);
    $vote_set=(int)get_post_meta($id, 'vote_set', true );
    $vote=$day_dept*(15+$vote_set)+1;
    $rate=get_post_meta($id, 'rating', true );
    // ngay het han
    $date = getdate();
    $year=$date['year']+1;
    //
    $data_gia = xu_ly_gia(get_post_meta($id, 'gia_san_pham', true ),$id,$title,$img);
    $schema_gia_product=$data_gia[4];
    $hien_thi_gia=$data_gia[0];
    // $schema_gia=$data_gia[1];
    // $schema_bang_gia=$data_gia[2];
    $dac_diem=get_post_meta($id, 'dac_diem', true );
    if($dac_diem!=""){
        $result_dac_diem='<div class="card card-1 sticker-1" style=" width: 100%; margin-top: 15px; padding: 15px; background:#f3f3f3; "> <strong style=" margin-bottom: 5px; display: block; ">Đặc điểm :</strong>';
        $result_dac_diem.=xu_ly_hien_thi_1($dac_diem,"Đặc điểm");
        $result_dac_diem.='</div>';
    }else{
        $result_dac_diem='';
    }
    // $schema_dac_diem=$dac_diem;
    $uu_diem=get_post_meta($id, 'uu_diem', true );
    if($uu_diem!=""){
        $result_uu_diem='<div class="card card-1 sticker-2" style=" width: 100%; margin-top: 15px; padding: 15px; background: #86e473; "> <strong style=" margin-bottom: 5px; display: block; ">Ưu điểm :</strong>';
        $result_uu_diem.=xu_ly_hien_thi_1($uu_diem);
        $result_uu_diem.='</div>';
    }else{
        $result_uu_diem='';
    }
    // $schema_uu_diem=$uu_diem;
    $nhuoc_diem=get_post_meta($id, 'nhuoc_diem', true );
    if($nhuoc_diem!=""){
        $result_nhuoc_diem='<div class="card card-1 sticker-3" style=" width: 100%; margin-top: 15px; padding: 15px; background: #efbdbd; "> <strong style=" margin-bottom: 5px; display: block; ">Nhược điểm :</strong>';
        $result_nhuoc_diem.=xu_ly_hien_thi_1($nhuoc_diem);
        $result_nhuoc_diem.='</div>';
    }else{
        $result_nhuoc_diem='';
    }
    // $schema_nhuoc_diem=$nhuoc_diem;
    $chinh_sach_dich_vu=get_post_meta($id, 'chinh_sach_dich_vu', true );
    if($chinh_sach_dich_vu!=""){
        $result_chinh_sach_dich_vu='<div class="card card-1 sticker-4" style=" width: 100%; margin-top: 15px; padding: 15px; background:#bdcde8; "> <strong style=" margin-bottom: 5px; display: block; ">Chính sách dịch vụ :</strong>';
        $result_chinh_sach_dich_vu.=xu_ly_hien_thi_1($chinh_sach_dich_vu);
        $result_chinh_sach_dich_vu.='</div>';
    }else{
        $result_chinh_sach_dich_vu='';
    }
    // $schema_khuyen_mai=$nhuoc_diem;
    $khuyen_mai=get_post_meta($id, 'khuyen_mai', true );
    if($khuyen_mai!=""){
        $result_khuyen_mai='<div class="card card-1 sticker-6" style=" width: 100%; margin-top: 15px; padding: 15px; background:#feff9d; "> <strong style=" margin-bottom: 5px; display: block; ">Khuyến mãi :</strong>';
        $result_khuyen_mai.=xu_ly_hien_thi_1($khuyen_mai);
        $result_khuyen_mai.='</div>';
    }else{
        $result_khuyen_mai='';
    }
    // $schema_chinh_sach_dich_vu=$chinh_sach_dich_vu;
    $thich_hop_su_dung_cho=get_post_meta($id, 'thich_hop_su_dung_cho', true );
    if($thich_hop_su_dung_cho!=""){
        $result_thich_hop_su_dung_cho='<div class="card card-1 sticker-5" style=" width: 100%; margin-top: 15px; padding: 15px; background:#e0d8d8; "> <strong style=" margin-bottom: 5px; display: block; ">Thích hợp sử dụng cho :</strong>';
        $result_thich_hop_su_dung_cho.=xu_ly_hien_thi_1($thich_hop_su_dung_cho);
        $result_thich_hop_su_dung_cho.='</div>';
    }else{
        $result_thich_hop_su_dung_cho='';
    }
    // $schema_thich_hop_su_dung_cho=$thich_hop_su_dung_cho;
    //  hien thi san pham lien quan
    $post_lien_quan=get_posts( array( 'numberposts' => 6,'category' => $cate->term_id,'orderby' => 'post_date', 'order' => 'DESC', ) );
    $url_related_post="";$title_related_post="";$img_related_post="";
    $result_related_post='<aside class="related-product" style="margin-top: 23px;"> <h4>Sản phẩm tương tự</h4> <ul>';
    $is_set_related=true;
    foreach($post_lien_quan as $post){
        if($post->ID !== $id){
            $is_set_related=false;
            $url_related_post=get_permalink($post->ID);
            $title_related_post=$post->post_title;
            $img_related_post=wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' );
            $result_related_post.='<li style=" overflow: auto; "><img style=" width: 80px; height: 80px;" class="thumail-porsuct-footer lazyload" data-src="'.$img_related_post.'" alt="'.$title_related_post.'" src="'.get_stylesheet_directory_uri().'/templates/assets/img/lazy-150x150.png">';
            $result_related_post.='<a class="tdn" href="'.$url_related_post.'" title="'.$title_related_post.'" style=" margin-top: 8px; "> <h4>'.$title_related_post.'</h4> </a> </li>';
        }
    }
    $result_related_post.='</ul></aside>';
    if($is_set_related) $result_related_post="";
    // xu ly mp3;
    $mp3_url=wp_get_attachment_url(get_post_meta($id, 'add_mp3', true ));
    $id_mp3=get_post_meta($id, 'add_mp3', true );
    $fun_triger='';$data_mp3='';
    if(!empty($id_mp3)){
        $fun_triger='AudioClick()';
        $data_mp3='<audio id="myAudio-1"> <source src="'.$mp3_url.'" type="audio/mp3"> </audio><script> function AudioClick(){ let x = document.getElementById("myAudio-1"); if (x.duration > 0 && !x.paused) { x.pause();change_play(); } else { x.play(); scroll_content();change_pause();} } </script>';
    }else{
        $fun_triger='AudioClick()';
        $data_mp3='<audio id="myAudio-1"></audio><script> function AudioClick(){ let x = document.getElementById("myAudio-1"); if (x.duration > 0 && !x.paused) { x.pause(); } else { x.play(); scroll_content(); } } </script>';
    }
    // xu ly hien thi random sort_mt post
    $args = array( 'posts_per_page' => 3, 'orderby' => 'rand','category' =>$cate->term_id,'post_type' => 'post' );
    $rand=rand(0,3);
    if($date['mday']-$rand>0){
        $ngay=$date['mday']-$rand;
    }else{
        $ngay=1;
    }
    $rand_posts = get_posts( $args );
    $random_text='<div style="background-color: antiquewhite;padding: 10px; border: 1px #e06748 dashed; "><time itemprop="dateModified" datetime="'.$date['year'].'-'.$date['mon'].'-'.$ngay.'" style="color: blue;" >'.$ngay.'/'.$date['mon'].'/'.$date['year'].'</time>';
    foreach($rand_posts as $post){
        $random_text.='<p><strong>'.$post->post_title.'</strong> : '.get_post_meta($post->ID, 'mo_ta_ngan', true ).'.</p>';
    }
    $random_text.='</div>';
    wp_reset_postdata();
?>