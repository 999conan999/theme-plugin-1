<!-- Top -->
<?php
    $home=get_home_url();
    preg_match_all('/\/\/(.*)/',$home,$name_url);
    $name_website=$name_url[1][0];
?>
<div class="hder-top" style="background-color: #6d6d6d;padding: 6px;width: 101%;">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6" style="padding-left: 0px;">
                <p class="t-align" style="margin-bottom: 0px;font-size: 12px;color: white;margin-top: 3px;">Chào mừng bạn đến với <strong><?php echo $name_website; ?></strong></p>
            </div>
            <div class="col-md-12 col-lg-6 dnone" style="text-align: end;">
                <a href="#" title="kiểm tra đơn hàng" style=" color: white; font-size: 12px; display: inline-block; ">Kiểm tra đơn hàng | </a>
                <a href="#" title="Tài Khoản" style=" color: white; font-size: 12px; display: inline-block; ">Tài Khoản <i class="icon-user"></i></a>
            </div>
        </div>
    </div>
</div>
<!-- Main -->
<div class="container df">
    <div class="row hder-main">
        <div class="col-2 col-xs-2 col-sm-2 icon-mb w-au">
            <span>
                <span class="iconDanhdev-menu mt-25 icon-list-ul" id="menu-click"></span>
            </span>
        </div>
        <div class="col-8 col-xs-8 col-sm-8 col-lg-3 w-au logo-p" itemscope="" itemtype="http://schema.org/Brand">
            <a href="<?php echo get_home_url() ?>" itemprop="url" title="Trang chủ" class="logo-ab">
                <!-- them them anh logo cho nay  -->
                <img itemprop="logo" src="<?php echo get_stylesheet_directory_uri().'/templates/assets/img/cofa_vn.png';?>" alt="cofa.vn" title="cofa.vn" width="195" height="70" id="animation-img">
            </a>
        </div>
        <div class="col-2 col-xs-2 col-sm-2 cart-mb w-au">
        </div>
        <div class="col-xs-12 col-sm-12 col-lg-5 dy">
            <form class="search" style=" display: flex; " action="<?php echo get_home_url().'/';?>" >
                <input type="text" name="s" class="search-input" id="search-input" placeholder="Tìm kiếm sản phẩm" autocomplete="off">
                <input type="submit" class="bnt-search" value="Tìm kiếm" style="cursor: pointer;">
            </form>
        </div>
        <div class="col-lg-4 cart-desktop">
            <div class="contact-p">
                <!-- them them anh contact cho nay  -->
                <div class="contact-num-p" style=" text-align: right;margin-bottom: 5px; ">Viettel: <b style=" color: mediumvioletred; ">0326 397 884</b></div>
                <div class="contact-num-p" style=" text-align: right; ">Mobiphone: <b style=" color: green; ">093 899 1602</b></div>
            </div>
            <div class="cart-icon">
                <span class="cart-show">
                    Giỏ Hàng
                </span>
                
            </div>
        </div>
    </div>
</div>
<!-- Header bottom -->
<nav itemtype="https://schema.org/SiteNavigationElement" itemscope="" class="danh-menu" id="menu-d" style="display: none;z-index: 98;box-shadow:-8px 2px 1px rgb(216 129 113), 0 6px 6px rgb(255 255 255 / 23%)">
    <div class="container menu-anbinhnew-com-container">
    <ul id="menu-vothanhdanh-bk" class="menu">
        <li class="main-menu-item  menu-item-even menu-item-depth-0 menu-item-has-children" itemprop="name"><a href="<?php echo $home;?>" itemprop="url">Trang chủ</a></li>      
        <?php
            $menu_item=get_term_meta($cate->term_id, 'menu_item', true );
            if($menu_item!=0){
                foreach($menu_item as $id_cateZ){
                    $url_cateZ=get_category_link($id_cateZ);
                    $name_cateZ=get_cat_name($id_cateZ);
                    echo '<li class="main-menu-item  menu-item-even menu-item-depth-0 menu-item-has-children" itemprop="name"><a href="'.$url_cateZ.'" itemprop="url">'.$name_cateZ.'</a></li>';
                }
            }
        ?>
    </ul>
    </div>
</nav>