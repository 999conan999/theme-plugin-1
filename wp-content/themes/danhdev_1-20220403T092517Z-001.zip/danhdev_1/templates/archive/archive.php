<?php
    $data_setup= fs_get_data_theme('data_setup');
    require_once(get_stylesheet_directory().'/templates/archive/control_archive.php');
?>
<!DOCTYPE html>
<html lang="vi" class=" w-mod-ix">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="robots" content="max-image-preview:large">
    <title>Beat đầu tư | Chia sẻ kiến thức tài chính chứng khoán forex &amp; tiền điện tử</title>
    <style type="text/css"><?php require_once(get_stylesheet_directory().'/templates/assets/css/style_home.php'); ?></style>
    <meta name="description"
        content="⭐ Beat đầu tư ⭐ là kênh chia sẻ các kiến thức hữu ích nhất về đầu từ tài chính , đầu tư chứng khoán , forex và tiền điện tử.">
    <meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">
    <link rel="canonical" href="https://beatdautu.com/">
    <meta property="og:locale" content="vi_VN">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Beat đầu tư | Chia sẻ kiến thức tài chính chứng khoán forex &amp; tiền điện tử">
    <meta property="og:description"
        content="⭐ Beat đầu tư ⭐ là kênh chia sẻ các kiến thức hữu ích nhất về đầu từ tài chính , đầu tư chứng khoán , forex và tiền điện tử.">
    <meta property="og:url" content="https://beatdautu.com/">
    <meta property="og:site_name" content="Beat Đầu Tư">
    <meta property="article:modified_time" content="2021-06-23T04:29:48+00:00">
    <meta property="og:image"
        content="https://beatdautu.com/wp-content/uploads/2021/05/Moi-Blockchain-hoat-dong-tuong-tu-nhu-mot-he-thong-du-lieu-phan-tan-khong-chiu-su-quan-ly-cua-bat-ky-mot-co-quan-nao.jpg">
    <meta property="og:image:width" content="640">
    <meta property="og:image:height" content="360">
    <meta name="twitter:card" content="summary_large_image">
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
        .elementor-kit-1073 {
            --e-global-color-primary: #6EC1E4;
            --e-global-color-secondary: #54595F;
            --e-global-color-text: #7A7A7A;
            --e-global-color-accent: #61CE70;
            --e-global-color-31e8: #4054B2;
            --e-global-color-2001: #23A455;
            --e-global-color-1ea6: #000;
            --e-global-color-50e7: #FFF;
            --e-global-typography-primary-font-family: "Roboto";
            --e-global-typography-primary-font-weight: 600;
            --e-global-typography-secondary-font-family: "Roboto Slab";
            --e-global-typography-secondary-font-weight: 400;
            --e-global-typography-text-font-family: "Roboto";
            --e-global-typography-text-font-weight: 400;
            --e-global-typography-accent-font-family: "Roboto";
            --e-global-typography-accent-font-weight: 500;
        }

        .elementor-section.elementor-section-boxed>.elementor-container {
            max-width: 1170px;
        }


        h1.entry-title {
            display: var(--page-title-display);
        }

        @media(max-width:1024px) {
            .elementor-section.elementor-section-boxed>.elementor-container {
                max-width: 1024px;
            }
        }

        @media(max-width:767px) {
            .elementor-section.elementor-section-boxed>.elementor-container {
                max-width: 767px;
            }
        }
        .rll-youtube-player {
            position: relative;
            padding-bottom: 56.23%;
            height: 0;
            overflow: hidden;
            max-width: 100%;
        }

        .rll-youtube-player:focus-within {
            outline: 2px solid currentColor;
            outline-offset: 5px;
        }

        .rll-youtube-player iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 100;
            background: 0 0
        }

        .rll-youtube-player img {
            bottom: 0;
            display: block;
            left: 0;
            margin: auto;
            max-width: 100%;
            width: 100%;
            position: absolute;
            right: 0;
            top: 0;
            border: none;
            height: auto;
            -webkit-transition: .4s all;
            -moz-transition: .4s all;
            transition: .4s all
        }

        .rll-youtube-player img:hover {
            -webkit-filter: brightness(75%)
        }

        .rll-youtube-player .play {
            height: 100%;
            width: 100%;
            left: 0;
            top: 0;
            position: absolute;
            background: url(https://beatdautu.com/wp-content/plugins/wp-rocket/assets/img/youtube.png) no-repeat center;
            background-color: transparent !important;
            cursor: pointer;
            border: none;
        }
        .boxdetail img {
            height: auto
        }
    </style>
      
    <link rel="icon" href="https://beatdautu.com/wp-content/uploads/2021/05/cropped-logo-32x32.png" sizes="32x32">
    <link rel="icon" href="https://beatdautu.com/wp-content/uploads/2021/05/cropped-logo-192x192.png" sizes="192x192">
    <link rel="apple-touch-icon" href="https://beatdautu.com/wp-content/uploads/2021/05/cropped-logo-180x180.png">
    <meta name="msapplication-TileImage"
        content="https://beatdautu.com/wp-content/uploads/2021/05/cropped-logo-270x270.png">
</head>

<body class="home page-template page-template-home-page page-template-home-page-php page page-id-2013 light-mode wp-schema-pro-2.7.2 jkit-color-scheme elementor-default elementor-kit-1073 elementor-page elementor-page-2013">

    <?php require_once(get_stylesheet_directory().'/templates/header/header.php'); ?>
    <?php 
        if($template_selected=='0'){
            require_once(get_stylesheet_directory().'/templates/archive/archive_00.php');
        }elseif($template_selected=='1'){
            require_once(get_stylesheet_directory().'/templates/archive/archive_01.php');
            echo $pageing;
        }elseif($template_selected=='2'){
            require_once(get_stylesheet_directory().'/templates/archive/archive_02.php');
        }
    ?>
    <?php require_once(get_stylesheet_directory().'/templates/footer/footer.php'); ?>

</body>

</html>