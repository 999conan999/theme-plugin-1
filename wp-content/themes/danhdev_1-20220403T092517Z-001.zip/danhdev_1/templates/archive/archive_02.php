<div data-elementor-type="wp-page" data-elementor-id="6998" class="elementor elementor-6998"
    data-elementor-settings="[]">
    <div class="elementor-inner">
        <div class="elementor-section-wrap">
            <section  class="elementor-section elementor-top-section elementor-element elementor-element-950c07b elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="950c07b" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-e1aa9d6"
                            data-id="e1aa9d6" data-element_type="column">
                            <div class="elementor-column-wrap elementor-element-populated">
                                <div class="elementor-widget-wrap">
                                    <div class="elementor-element elementor-element-0ea22e7 elementor-widget elementor-widget-heading"
                                        data-id="0ea22e7" data-element_type="widget" data-widget_type="heading.default">
                                        <div class="elementor-widget-container">
                                            <h2 class="elementor-heading-title elementor-size-default">HỌC FOREX A-Z
                                            </h2>
                                        </div>
                                    </div>
        
                                    <div class="elementor-element elementor-element-7aa9a76 elementor-tabs-alignment-center elementor-tabs-view-horizontal elementor-widget elementor-widget-tabs"
                                        data-id="7aa9a76" data-element_type="widget" data-widget_type="tabs.default">
                                        <div class="elementor-widget-container">
                                            <div class="elementor-tabs">
                                                
                                                <div class="elementor-tabs-content-wrapper" role="tablist" aria-orientation="vertical">
 
                                                    <div id="elementor-tab-content-1281" class="elementor-tab-content elementor-clearfix elementor-active" data-tab="1" role="tabpanel" aria-labelledby="elementor-tab-title-1281" tabindex="0" style="display: block;">

                                                        <div class="box" >
                                                            <div class="title">
                                                                <a href="Javascript:;" class="xemthem" data-wpel-link="internal"> Phần 1: Forex Nhập Môn – Khái niệm forex  <i aria-hidden="true" class="fas fa-chevron-right"></i></a>
                                                            </div>

                                                            <div class="boxs" style="display: none;" >
                                                                <div class="boxdetail">
                                                                    <div class="crp_related  ">
                                                                        <p class="ftwp-heading">✔️ Chức năng và ưu điểm: </p>
                                                                        <ul>
                                                                            <li> <span class="crp_title">KYC là gì? Những điều bạn cần biết để xác minh KYC</span> 
                                                                            </li>
                                                                            <li><span class="crp_title">AML là gì? Cách xác minh KYC trong quy trình AML từ A đến
                                                                                        Z</span> </li>
                                                                            <li> <span class="crp_title">Sàn Gate.io là gì? Review về sàn giao dịch Gate.io từ A -
                                                                                        Z</span> </li>
                                                                            <li><span class="crp_title">Top 10 Token nền tảng hệ sinh thái BSC
                                                                                        - Điểm danh…</span> </li>
                                                                            <li><span class="crp_title">Top 10 sàn giao dịch tiền ảo uy tín
                                                                                        2022 - Top sàn…</span> </li>
                                                                        </ul>
                                                                        <div class="crp_clear"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="boxdetail">
                                                                    <div class="crp_related re  ">
                                                                        <p class="ftwp-headings">🚀 Giao diện thích hợp sử dụng cho : </p>
                                                                        <ul>
                                                                            <li><span class="crp_title">KYC là gì? Những điều bạn cần biết để xác minh KYC</span> 
                                                                            </li>
                                                                            <li> <span class="crp_title">AML là gì? Cách xác minh KYC trong quy trình AML từ A đến
                                                                                        Z</span> </li>
                                                                            <li> <span class="crp_title">Sàn Gate.io là gì? Review về sàn giao dịch Gate.io từ A -
                                                                                        Z</span> </li>
                                                                            <li><span class="crp_title">Top 10 Token nền tảng hệ sinh thái BSC
                                                                                        - Điểm danh…</span> </li>
                                                                            <li> <span class="crp_title">Top 10 sàn giao dịch tiền ảo uy tín
                                                                                        2022 - Top sàn…</span> </li>
                                                                        </ul>
                                                                        <div class="crp_clear"></div>
                                                                    </div>
                                                                </div>
                                                                <div style="text-align: center;">
                                                                    <a class="fasc-button fasc-size-large fasc-type-flat fasc-rounded-medium fasc-style-bold" style="background-color: #4ac229; color: #ffffff;" href="https://docs.google.com/spreadsheets/d/1DJM4_BcqWNnJ7FQ4Djw5ljnyMM3uZKszAaPUfQbpGQA/" target="_blank" rel="noopener nofollow external noreferrer" data-wpel-link="external">Xem Demo</a>
                                                                    <a class="fasc-button fasc-size-large fasc-type-flat fasc-rounded-medium fasc-style-bold" style="background-color: #3861fb; color: #ffffff;display: inline-block;min-width: 116px;" href="https://docs.google.com/spreadsheets/d/1DJM4_BcqWNnJ7FQ4Djw5ljnyMM3uZKszAaPUfQbpGQA/" target="_blank" rel="noopener nofollow external noreferrer" data-wpel-link="external">Tải xuống</a>
                                                                    <a class="fasc-button fasc-size-large fasc-type-flat fasc-rounded-medium fasc-style-bold" style="background-color: #c22929; color: #ffffff;display: inline-block;min-width: 234px;" href="https://docs.google.com/spreadsheets/d/1DJM4_BcqWNnJ7FQ4Djw5ljnyMM3uZKszAaPUfQbpGQA/" target="_blank" rel="noopener nofollow external noreferrer" data-wpel-link="external">Tham gia group hỗ trọ</a>
                                                                </div>

                                                            </div>
                                                        </div>

                                                        <div class="box">
                                                            <div class="title">

                                                                <a href="Javascript:;" class="xemthem"
                                                                    data-wpel-link="internal">Phần 2: Các công cụ phần
                                                                    mềm cần phải biết khi tham gia giao dịch forex <i
                                                                        aria-hidden="true"
                                                                        class="fas fa-chevron-right"></i></a>

                                                            </div>

                                                            <div class="boxs" style="display: none;">
                                                            <!-- <div class="boxs" > -->

                                                                <div class="links">
                                                                    <a href="https://beatdautu.com/mt4-la-gi/"
                                                                        data-wpel-link="internal" target="_blank">
                                                                        <img width="640" height="240"
                                                                            src="https://beatdautu.com/wp-content/uploads/2021/05/mt4-co-nhieu-tien-ich.jpg"
                                                                            class="attachment- size- wp-post-image entered lazyloaded"
                                                                            alt=""
                                                                            data-lazy-srcset="https://beatdautu.com/wp-content/uploads/2021/05/mt4-co-nhieu-tien-ich.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/mt4-co-nhieu-tien-ich-160x60.jpg 160w"
                                                                            data-lazy-sizes="(max-width: 640px) 100vw, 640px"
                                                                            data-lazy-src="https://beatdautu.com/wp-content/uploads/2021/05/mt4-co-nhieu-tien-ich.jpg"
                                                                            data-ll-status="loaded"
                                                                            sizes="(max-width: 640px) 100vw, 640px"
                                                                            srcset="https://beatdautu.com/wp-content/uploads/2021/05/mt4-co-nhieu-tien-ich.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/mt4-co-nhieu-tien-ich-160x60.jpg 160w"><noscript><img
                                                                                width="640" height="240"
                                                                                src="https://beatdautu.com/wp-content/uploads/2021/05/mt4-co-nhieu-tien-ich.jpg"
                                                                                class="attachment- size- wp-post-image"
                                                                                alt=""
                                                                                srcset="https://beatdautu.com/wp-content/uploads/2021/05/mt4-co-nhieu-tien-ich.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/mt4-co-nhieu-tien-ich-160x60.jpg 160w"
                                                                                sizes="(max-width: 640px) 100vw, 640px" /></noscript>
                                                                    </a>
                                                                    <div class="metalink">
                                                                        <a href="https://beatdautu.com/mt4-la-gi/"
                                                                            data-wpel-link="internal" class="dv3"
                                                                            target="_blank">MT4 là gì? Hướng dẫn cài đặt
                                                                            &amp; sử dụng phần mềm meta trader 4</a>
                                                                    </div>
                                                                </div>



                                                                <div class="links">
                                                                    <a href="https://beatdautu.com/mt5-la-gi/"
                                                                        data-wpel-link="internal" target="_blank">
                                                                        <img width="640" height="359"
                                                                            src="https://beatdautu.com/wp-content/uploads/2021/05/mt5-la-gi.jpg"
                                                                            class="attachment- size- wp-post-image entered lazyloaded"
                                                                            alt=""
                                                                            data-lazy-srcset="https://beatdautu.com/wp-content/uploads/2021/05/mt5-la-gi.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/mt5-la-gi-107x60.jpg 107w"
                                                                            data-lazy-sizes="(max-width: 640px) 100vw, 640px"
                                                                            data-lazy-src="https://beatdautu.com/wp-content/uploads/2021/05/mt5-la-gi.jpg"
                                                                            data-ll-status="loaded"
                                                                            sizes="(max-width: 640px) 100vw, 640px"
                                                                            srcset="https://beatdautu.com/wp-content/uploads/2021/05/mt5-la-gi.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/mt5-la-gi-107x60.jpg 107w"><noscript><img
                                                                                width="640" height="359"
                                                                                src="https://beatdautu.com/wp-content/uploads/2021/05/mt5-la-gi.jpg"
                                                                                class="attachment- size- wp-post-image"
                                                                                alt=""
                                                                                srcset="https://beatdautu.com/wp-content/uploads/2021/05/mt5-la-gi.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/mt5-la-gi-107x60.jpg 107w"
                                                                                sizes="(max-width: 640px) 100vw, 640px" /></noscript>
                                                                    </a>
                                                                    <div class="metalink">
                                                                        <a href="https://beatdautu.com/mt5-la-gi/"
                                                                            data-wpel-link="internal" class="dv3"
                                                                            target="_blank">MT5 là gì? Hướng dẫn sử dụng
                                                                            phần mềm MetaTrader 5 từ A – Z</a>
                                                                    </div>
                                                                </div>



                                                                <div class="links">
                                                                    <a href="https://beatdautu.com/mt6-la-gi/"
                                                                        data-wpel-link="internal" target="_blank">
                                                                        <img width="640" height="361"
                                                                            src="https://beatdautu.com/wp-content/uploads/2021/05/mt6-la-gi.jpg"
                                                                            class="attachment- size- wp-post-image entered lazyloaded"
                                                                            alt="nen tang mt6 la gi"
                                                                            data-lazy-srcset="https://beatdautu.com/wp-content/uploads/2021/05/mt6-la-gi.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/mt6-la-gi-106x60.jpg 106w"
                                                                            data-lazy-sizes="(max-width: 640px) 100vw, 640px"
                                                                            data-lazy-src="https://beatdautu.com/wp-content/uploads/2021/05/mt6-la-gi.jpg"
                                                                            data-ll-status="loaded"
                                                                            sizes="(max-width: 640px) 100vw, 640px"
                                                                            srcset="https://beatdautu.com/wp-content/uploads/2021/05/mt6-la-gi.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/mt6-la-gi-106x60.jpg 106w"><noscript><img
                                                                                width="640" height="361"
                                                                                src="https://beatdautu.com/wp-content/uploads/2021/05/mt6-la-gi.jpg"
                                                                                class="attachment- size- wp-post-image"
                                                                                alt="nen tang mt6 la gi"
                                                                                srcset="https://beatdautu.com/wp-content/uploads/2021/05/mt6-la-gi.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/mt6-la-gi-106x60.jpg 106w"
                                                                                sizes="(max-width: 640px) 100vw, 640px" /></noscript>
                                                                    </a>
                                                                    <div class="metalink">
                                                                        <a href="https://beatdautu.com/mt6-la-gi/"
                                                                            data-wpel-link="internal" class="dv3"
                                                                            target="_blank">MT6 là gì? Nền tảng tài
                                                                            chính MT6 có phải là một “cú lừa”?</a>
                                                                    </div>
                                                                </div>



                                                                <div class="links">
                                                                    <a href="https://beatdautu.com/tradingview-la-gi/"
                                                                        data-wpel-link="internal" target="_blank">
                                                                        <img width="640" height="480"
                                                                            src="https://beatdautu.com/wp-content/uploads/2021/05/tradingview-la-gi-cach-su-dung-tradingview.jpg"
                                                                            class="attachment- size- wp-post-image entered lazyloaded"
                                                                            alt="TradingView là gì? Cách sử dụng TradingView chi tiết nhất"
                                                                            data-lazy-srcset="https://beatdautu.com/wp-content/uploads/2021/05/tradingview-la-gi-cach-su-dung-tradingview.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/tradingview-la-gi-cach-su-dung-tradingview-80x60.jpg 80w"
                                                                            data-lazy-sizes="(max-width: 640px) 100vw, 640px"
                                                                            data-lazy-src="https://beatdautu.com/wp-content/uploads/2021/05/tradingview-la-gi-cach-su-dung-tradingview.jpg"
                                                                            data-ll-status="loaded"
                                                                            sizes="(max-width: 640px) 100vw, 640px"
                                                                            srcset="https://beatdautu.com/wp-content/uploads/2021/05/tradingview-la-gi-cach-su-dung-tradingview.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/tradingview-la-gi-cach-su-dung-tradingview-80x60.jpg 80w"><noscript><img
                                                                                width="640" height="480"
                                                                                src="https://beatdautu.com/wp-content/uploads/2021/05/tradingview-la-gi-cach-su-dung-tradingview.jpg"
                                                                                class="attachment- size- wp-post-image"
                                                                                alt="TradingView là gì? Cách sử dụng TradingView chi tiết nhất"
                                                                                srcset="https://beatdautu.com/wp-content/uploads/2021/05/tradingview-la-gi-cach-su-dung-tradingview.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/tradingview-la-gi-cach-su-dung-tradingview-80x60.jpg 80w"
                                                                                sizes="(max-width: 640px) 100vw, 640px" /></noscript>
                                                                    </a>
                                                                    <div class="metalink">
                                                                        <a href="https://beatdautu.com/tradingview-la-gi/"
                                                                            data-wpel-link="internal" class="dv3"
                                                                            target="_blank">TradingView là gì? Tính năng
                                                                            &amp; Cách sử dụng TradingView</a>
                                                                    </div>
                                                                </div>



                                                                <div class="links">
                                                                    <a href="https://beatdautu.com/huong-dan-dang-ky-forex4you/"
                                                                        data-wpel-link="internal" target="_blank">
                                                                        <img width="640" height="480"
                                                                            src="https://beatdautu.com/wp-content/uploads/2021/05/fx4-la-gi.jpg"
                                                                            class="attachment- size- wp-post-image entered lazyloaded"
                                                                            alt="Forex4you là gì? Hướng dẫn đăng ký Forex4you từ A đến Z"
                                                                            data-lazy-srcset="https://beatdautu.com/wp-content/uploads/2021/05/fx4-la-gi.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/fx4-la-gi-80x60.jpg 80w"
                                                                            data-lazy-sizes="(max-width: 640px) 100vw, 640px"
                                                                            data-lazy-src="https://beatdautu.com/wp-content/uploads/2021/05/fx4-la-gi.jpg"
                                                                            data-ll-status="loaded"
                                                                            sizes="(max-width: 640px) 100vw, 640px"
                                                                            srcset="https://beatdautu.com/wp-content/uploads/2021/05/fx4-la-gi.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/fx4-la-gi-80x60.jpg 80w"><noscript><img
                                                                                width="640" height="480"
                                                                                src="https://beatdautu.com/wp-content/uploads/2021/05/fx4-la-gi.jpg"
                                                                                class="attachment- size- wp-post-image"
                                                                                alt="Forex4you là gì? Hướng dẫn đăng ký Forex4you từ A đến Z"
                                                                                srcset="https://beatdautu.com/wp-content/uploads/2021/05/fx4-la-gi.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/fx4-la-gi-80x60.jpg 80w"
                                                                                sizes="(max-width: 640px) 100vw, 640px" /></noscript>
                                                                    </a>
                                                                    <div class="metalink">
                                                                        <a href="https://beatdautu.com/huong-dan-dang-ky-forex4you/"
                                                                            data-wpel-link="internal" class="dv3"
                                                                            target="_blank">Sàn Forex4you là gì? Hướng
                                                                            dẫn đăng ký Forex4you từ A đến Z</a>
                                                                    </div>
                                                                </div>



                                                                <div class="links">
                                                                    <a href="https://beatdautu.com/lich-kinh-te-forex/"
                                                                        data-wpel-link="internal" target="_blank">
                                                                        <img width="640" height="480"
                                                                            src="https://beatdautu.com/wp-content/uploads/2021/05/lich-kinh-te-2.jpg"
                                                                            class="attachment- size- wp-post-image entered lazyloaded"
                                                                            alt=""
                                                                            data-lazy-srcset="https://beatdautu.com/wp-content/uploads/2021/05/lich-kinh-te-2.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/lich-kinh-te-2-80x60.jpg 80w"
                                                                            data-lazy-sizes="(max-width: 640px) 100vw, 640px"
                                                                            data-lazy-src="https://beatdautu.com/wp-content/uploads/2021/05/lich-kinh-te-2.jpg"
                                                                            data-ll-status="loaded"
                                                                            sizes="(max-width: 640px) 100vw, 640px"
                                                                            srcset="https://beatdautu.com/wp-content/uploads/2021/05/lich-kinh-te-2.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/lich-kinh-te-2-80x60.jpg 80w"><noscript><img
                                                                                width="640" height="480"
                                                                                src="https://beatdautu.com/wp-content/uploads/2021/05/lich-kinh-te-2.jpg"
                                                                                class="attachment- size- wp-post-image"
                                                                                alt=""
                                                                                srcset="https://beatdautu.com/wp-content/uploads/2021/05/lich-kinh-te-2.jpg 640w, https://beatdautu.com/wp-content/uploads/2021/05/lich-kinh-te-2-80x60.jpg 80w"
                                                                                sizes="(max-width: 640px) 100vw, 640px" /></noscript>
                                                                    </a>
                                                                    <div class="metalink">
                                                                        <a href="https://beatdautu.com/lich-kinh-te-forex/"
                                                                            data-wpel-link="internal" class="dv3"
                                                                            target="_blank">Lịch kinh tế Forex: Công cụ
                                                                            giúp Trader giao dịch hiệu quả</a>
                                                                    </div>
                                                                </div>



                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-cd57d0c elementor-widget elementor-widget-image" data-id="cd57d0c" data-element_type="widget" data-widget_type="image.default">
                                        <div class="elementor-widget-container">
                                             <img width="800" height="500"
                                                    src="https://beatdautu.com/wp-content/uploads/elementor/thumbs/30usd-paqftbev8ees4s8kx2k73ijw4v0ko593kkqryuwoso.jpg"
                                                    title="30usd" alt="30usd"
                                                    data-lazy-src="https://beatdautu.com/wp-content/uploads/elementor/thumbs/30usd-paqftbev8ees4s8kx2k73ijw4v0ko593kkqryuwoso.jpg"
                                                    data-ll-status="loaded"
                                                    class="entered lazyloaded"> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>