<?php
require_once(get_stylesheet_directory().'/templates/tag/tag.php');
?>